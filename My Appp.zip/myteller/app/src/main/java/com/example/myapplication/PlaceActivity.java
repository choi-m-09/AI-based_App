package com.example.myapplication;

import android.os.Bundle;

import androidx.annotation.Nullable;

public class PlaceActivity extends MainActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place);

    }
}
