package com.example.myapplication;

import android.os.Bundle;

import androidx.annotation.Nullable;

public class CamActivity extends ZoneActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cam);

    }
}
